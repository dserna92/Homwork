package project2;

public class Undergraduate extends Student {
	
	private String classRank;
	
	
	public Undergraduate(String studentName, int studentCreditHours, int studentQualityPoints, String classRank) {
		super(studentName, studentCreditHours, studentQualityPoints);
		this.classRank = classRank;
	}
	@Override
	public boolean eligibleForHonorSociety(int creditHours, int qualityPoints) {
		return gpa(creditHours, qualityPoints) > getGpaThreshold() &&
		           (classRank.equals("Junior") || classRank.equals("Senior"));
	}
	@Override
	public String toString() {
		return super.toString() + String.format(" %s", classRank);
	}
}
