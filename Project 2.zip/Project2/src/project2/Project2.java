/**
 * Author: David A. Serna
 * Date: March 08, 2025
 * Project Purpose: This program will be used to determine the eligible students to be admitted to an honor society.
 * */
package project2;

import java.util.ArrayList;
import java.util.Scanner;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;




public class Project2 {

	public static void main(String[] args) {
		
		
		ArrayList<Student> studentBody = new ArrayList();
		Scanner scanner = new Scanner(System.in);
		String degreeSought = null;
		try {
			BufferedWriter writer = new BufferedWriter(new FileWriter("StudetntBody.txt"));
			System.out.println("Please enter Student Name, Credit Hours, Quality Points, and Year: EX(Brown,William 72 230 Junior or"
					+ "Smith,John 21 82 Masters" );
			System.out.println("Enter \"exit\" when finished");
			
			while (true) {
				String name = scanner.next();
				if(name.equalsIgnoreCase("exit")) {
					break;
				}
				int creditHours = scanner.nextInt();
				int qualityPoints = scanner.nextInt();
				scanner.nextLine();
				String year = scanner.next();
				
				year = year.substring(0, 1).toUpperCase() + year.substring(1);
				
				if (year.equalsIgnoreCase("masters") || year.equalsIgnoreCase("doctorates")) {
					degreeSought = year;
				}
				
				Undergraduate undergraduate = new Undergraduate(name, creditHours, qualityPoints, year);
				
				Graduate graduate = new Graduate(name, creditHours, qualityPoints, degreeSought);
				
				double undergraduateGpa = undergraduate.gpa(creditHours, qualityPoints);
				double graduateGpa = graduate.gpa(creditHours,qualityPoints);
				
				
				
				
				}
		}
		catch (IOException e) {
		
			e.printStackTrace();
		}
		finally {
			scanner.close();
			
		}
	}

}
