package project2;

public class Graduate extends Student {
	
	private String degreeSought;
	public Graduate(String studentName, int studentCreditHours, int studentQualityPoints, String degreeSought) {
		super(studentName, studentCreditHours, studentQualityPoints);
		this.degreeSought = degreeSought;		
	}

	@Override
	public boolean eligibleForHonorSociety(int creditHours, int qualityPoints) {
	    return super.eligibleForHonorSociety(creditHours, qualityPoints) && degreeSought.equals("Master's");
	}

	@Override
	public String toString() {
        return super.toString() + String.format(" %s", degreeSought);
	}
	
}
