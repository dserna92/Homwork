package project2;



public class Student {

	private String studentName;
	private int studentCreditHours;
	private int studentQualityPoints;
	private static double gpaThreshold;
	
	
	
	public Student(String studentName, int studentCreditHours, int studentQualityPoints) {
		this.studentName = studentName;
		this.studentCreditHours = studentCreditHours;
		this.studentQualityPoints = studentQualityPoints;
	}
		
	
	//This method is to calculate the GPA of a student
	public double gpa(int creditHours, int qualityPoints) {
		if(creditHours == 0) {
			return 0.0;
		}
		return Math.round(((double) qualityPoints / creditHours) * 100.0) / 100.0 ;
	}
	
	public boolean eligibleForHonorSociety(int creditHours, int qualityPoints) {
		return (gpa(creditHours, qualityPoints) > gpaThreshold);
	
		}


	public static void setGpaThreshold(double gpaThreshold) {
		Student.gpaThreshold = gpaThreshold;}
	
	public static double getGpaThreshold() {
        return gpaThreshold;
	}
	@Override
	public String toString() {
		return String.format("%-s %.2f", studentName, gpa(studentCreditHours, studentCreditHours));
	}



}
